from django.shortcuts import render, redirect
from .forms import TaskForm
from datetime import date
from .models import Task
from django.http import JsonResponse

def home(request):
    today = date.today()
    today_tasks = Task.objects.filter(due_date=today)
    return render(request, 'tracker/home.html', {'today_tasks': today_tasks})

def create_task(request):
    form = TaskForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('home')
    return render(request, 'tracker/create_task.html', {'form': form})

def calendar_view(request):
    return render(request, 'tracker/calendar.html')

def tasks_json(request):
    tasks = Task.objects.all()
    events = []

    for task in tasks:
        events.append({
            'title': task.title,
            'start': task.date.isoformat(),
        })

    return JsonResponse(events, safe=False)

