from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('create/', views.create_task, name='create_task'),
    path('calendar/', views.calendar_view, name='calendar_view'),
    path('tasks-json/', views.tasks_json, name='tasks_json'), 
   
]
